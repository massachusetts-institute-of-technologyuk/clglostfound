
import React, { useEffect, useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from 'react-router-dom'
import Home from './pages/Home.jsx'
import Register from './pages/RegisterLost.jsx'
import Report from './pages/ReportFound.jsx'
import Admin from './pages/Admin.jsx'

export default function App(){
  const [dark, setDark] = useState(true)
  useEffect(()=>{ document.documentElement.style.background = dark ? '' : '#f5f7fb' },[dark])
  return (
    <Router>
      <header className='nav glass'>
        <div className='logo'>Campus Lost & Found Hub</div>
        <div>
          <Link className='btn' to='/'>Home</Link>
          <Link className='btn' to='/register'>Register Lost</Link>
          <Link className='btn' to='/report'>Report Found</Link>
          <Link className='btn' to='/admin'>Admin</Link>
          <button title='toggle theme' className='btn' onClick={()=>setDark(d=>!d)}>{dark ? 'Dark' : 'Light'}</button>
        </div>
      </header>

      <main>
        <Routes>
          <Route path='/' element={<Home/>} />
          <Route path='/register' element={<Register/>} />
          <Route path='/report' element={<Report/>} />
          <Route path='/admin/*' element={<Admin/>} />
        </Routes>
      </main>

      <footer className='footer'>
        © Campus Lost & Found Hub — demo
      </footer>
    </Router>
  )
}
