
import React from 'react'
import { Link } from 'react-router-dom'

const SAMPLE = [
  {id:'s1', itemName:'Blue Water Bottle', category:'Bottle', lastSeen:'Library 2nd floor', description:"Blue Milton bottle with name 'Rahul' scribbled.", image:'/images/bottle1.svg'},
  {id:'s2', itemName:'Black Gel Pen', category:'Stationery', lastSeen:'Cafeteria', description:'Black Trimax gel pen.', image:'/images/pen1.svg'},
  {id:'s3', itemName:'Sky Blue Backpack', category:'Bag', lastSeen:'Classroom B-204', description:'Skyblue Wildcraft bag with laptop compartment.', image:'/images/bag1.svg'},
]

export default function Home(){
  return (
    <div className='container'>
      <section className='hero glass'>
        <div>
          <h1>Lost Something? Found Something? We Connect You.</h1>
          <p className='lead'>Register lost items with a token or report found items with location — fast and secure.</p>
          <div className='hero-ctas'>
            <Link to='/register' className='btn primary'>Register Lost Item</Link>
            <Link to='/report' className='btn alt'>Report Found Item</Link>
          </div>
        </div>
        <div className='carousel'>
          <div className='card-small glass'>
            <img src={SAMPLE[0].image} alt='sample' />
            <div style={{padding:10}}>
              <h3>{SAMPLE[0].itemName}</h3>
              <div className='muted'>{SAMPLE[0].category} • {SAMPLE[0].lastSeen}</div>
              <p style={{marginTop:6}}>{SAMPLE[0].description}</p>
            </div>
          </div>
        </div>
      </section>

      <section className='features'>
        <div className='feature glass'><h4>Secure Registration</h4><p>Only token holders can register lost items.</p></div>
        <div className='feature glass'><h4>Fast Reporting</h4><p>Found reports reach admin instantly with location.</p></div>
        <div className='feature glass'><h4>Smart Dashboard</h4><p>Manage tokens, view reports and mark items recovered.</p></div>
      </section>
    </div>
  )
}
