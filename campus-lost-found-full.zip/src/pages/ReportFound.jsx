
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'

function loadItems(){ try{ return JSON.parse(localStorage.getItem('clf_items')||'[]') }catch{return[]} }
function saveReport(r){ const rep = JSON.parse(localStorage.getItem('clf_reports')||'[]'); rep.unshift(r); localStorage.setItem('clf_reports', JSON.stringify(rep)) }

export default function Report(){
  const items = loadItems()
  const [form, setForm] = useState({itemId:'', description:'', locationText:'', coords:null})
  const [err, setErr] = useState('')
  const navigate = useNavigate()

  const detect = ()=> {
    if(!navigator.geolocation){ setErr('Geolocation not supported'); return }
    navigator.geolocation.getCurrentPosition(p=> setForm({...form, coords:{lat:p.coords.latitude,lng:p.coords.longitude}}), e=> setErr('Unable to detect location: '+e.message))
  }

  const submit = (e)=>{
    e.preventDefault()
    setErr('')
    if(!form.itemId){ setErr('Select an item'); return }
    if(!form.locationText && !form.coords){ setErr('Provide location or detect'); return }
    const rep = {...form, id:'rep-'+Date.now(), reportedAt:new Date().toISOString()}
    saveReport(rep)
    alert('Report submitted; admin will review.')
    navigate('/')
  }

  return (
    <div className='container formpage'>
      <h2>Report Found Item</h2>
      <form className='form glass' onSubmit={submit}>
        <label>Item (choose approximate match)
          <select value={form.itemId} onChange={e=>setForm({...form,itemId:e.target.value})}>
            <option value=''>-- choose --</option>
            {items.map(it => <option key={it.id} value={it.id}>{it.itemName} — {it.category}</option>)}
          </select>
        </label>
        <label>Description<textarea value={form.description} onChange={e=>setForm({...form,description:e.target.value})}></textarea></label>
        <label>Your Location (text)<input value={form.locationText} onChange={e=>setForm({...form,locationText:e.target.value})} /></label>
        <div style={{gridColumn:'span 2', display:'flex', gap:10}}>
          <button type='button' className='btn' onClick={detect}>Detect my location</button>
          <div style={{alignSelf:'center', color:'rgba(230,238,248,0.7)'}}>{form.coords? `${form.coords.lat.toFixed(4)}, ${form.coords.lng.toFixed(4)}` : ''}</div>
        </div>
        <div style={{gridColumn:'span 2'}} className='row'>
          <button className='btn primary' type='submit'>Send Report</button>
        </div>
        {err && <div style={{color:'#ffb4b4'}}>{err}</div>}
      </form>
    </div>
  )
}
