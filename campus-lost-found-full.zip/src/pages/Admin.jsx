
import React, { useState } from 'react'

function loadItems(){ try{ return JSON.parse(localStorage.getItem('clf_items')||'[]') }catch{return[]} }
function loadReports(){ try{ return JSON.parse(localStorage.getItem('clf_reports')||'[]') }catch{return[]} }
function loadTokens(){ try{ return JSON.parse(localStorage.getItem('clf_tokens')||'[]') }catch{return[]} }
function saveTokens(t){ localStorage.setItem('clf_tokens', JSON.stringify(t)) }

export default function Admin(){
  const [authed, setAuthed] = useState(sessionStorage.getItem('clf_admin')==='1')
  const [pass, setPass] = useState('')
  const [tab, setTab] = useState('lost')
  const items = loadItems()
  const reports = loadReports()
  const tokens = loadTokens()

  const login = ()=> {
    if(pass==='admin123'){ sessionStorage.setItem('clf_admin','1'); setAuthed(true) } else alert('Wrong password (demo: admin123)')
  }

  const genToken = ()=> {
    const t = 'TKN-'+Math.random().toString(36).slice(2,10).toUpperCase()
    const arr = [{token:t, used:false, createdAt:new Date().toISOString()}, ...tokens]
    saveTokens(arr)
    alert('Generated '+t)
    window.location.reload()
  }

  const markUsed = (tk)=> {
    const arr = tokens.map(x=> x.token===tk ? {...x, used:true} : x)
    saveTokens(arr); window.location.reload()
  }

  if(!authed) return (
    <div className='container'>
      <div className='glass' style={{padding:20}}>
        <h3>Admin Login</h3>
        <input placeholder='password' type='password' value={pass} onChange={e=>setPass(e.target.value)} />
        <div style={{marginTop:10}}>
          <button className='btn primary' onClick={login}>Login</button>
        </div>
        <p style={{color:'rgba(230,238,248,0.6)'}}>Demo password: <code>admin123</code></p>
      </div>
    </div>
  )

  return (
    <div className='container admin-panel'>
      <div className='glass' style={{padding:12, display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h3>Admin Dashboard</h3>
        <div>
          <button className='btn' onClick={()=>{sessionStorage.removeItem('clf_admin'); setAuthed(false)}}>Logout</button>
          <button className='btn' onClick={genToken}>Generate Token</button>
        </div>
      </div>

      <div className='tabs glass' style={{padding:10, marginTop:12}}>
        <button className='btn' onClick={()=>setTab('lost')}>Lost Items</button>
        <button className='btn' onClick={()=>setTab('found')}>Found Reports</button>
        <button className='btn' onClick={()=>setTab('tokens')}>Token Management</button>
      </div>

      {tab==='lost' && (
        <div className='cards'>
          {items.length===0 && <div className='glass' style={{padding:12}}>No lost items yet.</div>}
          {items.map(it=>(
            <div className='card glass' key={it.id}>
              <h4>{it.itemName}</h4>
              <div className='muted'>{it.category} • {it.lastSeen}</div>
              <p>{it.description}</p>
              <div style={{display:'flex',gap:8}}>
                <button className='btn' onClick={()=>{navigator.clipboard.writeText(JSON.stringify(it)); alert('Copied')}}>Copy JSON</button>
                <button className='btn' onClick={()=>{ if(confirm('Delete?')){ const arr = items.filter(x=>x.id!==it.id); localStorage.setItem('clf_items', JSON.stringify(arr)); window.location.reload() } }}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab==='found' && (
        <div className='cards'>
          {reports.length===0 && <div className='glass' style={{padding:12}}>No reports yet.</div>}
          {reports.map(r=>(
            <div className='card glass' key={r.id}>
              <h4>Report for { (items.find(i=>i.id===r.itemId)||{}).itemName || 'Unknown' }</h4>
              <div className='muted'>{r.locationText || (r.coords? `${r.coords.lat},${r.coords.lng}`:'—')}</div>
              <p>{r.description}</p>
              <div style={{display:'flex',gap:8}}>
                <button className='btn' onClick={()=>{navigator.clipboard.writeText(JSON.stringify(r)); alert('Copied')}}>Copy JSON</button>
                <button className='btn' onClick={()=>{ if(confirm('Delete?')){ const arr = reports.filter(x=>x.id!==r.id); localStorage.setItem('clf_reports', JSON.stringify(arr)); window.location.reload() } }}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab==='tokens' && (
        <div className='cards'>
          {tokens.length===0 && <div className='glass' style={{padding:12}}>No tokens yet.</div>}
          {tokens.map(t=>(
            <div className='token glass' key={t.token}>
              <div><strong>{t.token}</strong><div className='muted'>Created: {new Date(t.createdAt).toLocaleString()}</div></div>
              <div style={{display:'flex',gap:8}}>
                {!t.used && <button className='btn' onClick={()=>markUsed(t.token)}>Mark used</button>}
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  )
}
