
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'

function loadTokens(){ try{ return JSON.parse(localStorage.getItem('clf_tokens')||'[]') }catch{return[]} }
function saveItem(it){ const items = JSON.parse(localStorage.getItem('clf_items')||'[]'); items.unshift(it); localStorage.setItem('clf_items', JSON.stringify(items)) }

export default function Register(){
  const [form, setForm] = useState({name:'', studentId:'', email:'', token:'', itemName:'', category:'', description:'', lastSeen:'', image:''})
  const [err, setErr] = useState('')
  const navigate = useNavigate()

  const validateToken = (t)=> { const tokens = loadTokens(); return tokens.find(x=>x.token===t && !x.used) }

  const handleSubmit = (e)=>{
    e.preventDefault()
    setErr('')
    if(!validateToken(form.token)){ setErr('Invalid or used token'); return }
    if(!form.name||!form.studentId||!form.email||!form.itemName||!form.category||!form.lastSeen){ setErr('Please fill required fields'); return }
    const item = {...form, id:'lost-'+Date.now(), reportedAt:new Date().toISOString()}
    saveItem(item)
    // mark token used
    const tokens = loadTokens().map(t=> t.token===form.token ? {...t, used:true} : t)
    localStorage.setItem('clf_tokens', JSON.stringify(tokens))
    navigate('/')
  }

  return (
    <div className='container formpage'>
      <h2>Register Lost Item</h2>
      <form className='form glass' onSubmit={handleSubmit}>
        <label>Full Name<input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} /></label>
        <label>Student ID<input value={form.studentId} onChange={e=>setForm({...form,studentId:e.target.value})} /></label>
        <label>Email<input value={form.email} onChange={e=>setForm({...form,email:e.target.value})} /></label>
        <label>Token Number<input value={form.token} onChange={e=>setForm({...form,token:e.target.value})} /></label>
        <label>Item Name<input value={form.itemName} onChange={e=>setForm({...form,itemName:e.target.value})} /></label>
        <label>Category<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}><option value=''>Choose</option><option>Bag</option><option>Bottle</option><option>Pen</option><option>Electronics</option><option>ID Cards</option><option>Stationery</option><option>Other</option></select></label>
        <label>Last Seen Location<input value={form.lastSeen} onChange={e=>setForm({...form,lastSeen:e.target.value})} /></label>
        <label>Description<textarea value={form.description} onChange={e=>setForm({...form,description:e.target.value})}></textarea></label>
        <div style={{gridColumn:'span 2'}} className='row'>
          <button className='btn primary' type='submit'>Submit & Register</button>
        </div>
        {err && <div style={{color:'#ffb4b4'}}>{err}</div>}
      </form>
    </div>
  )
}
