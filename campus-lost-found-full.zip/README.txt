Run this app:
1) npm install
2) npm run dev

Demo admin password: admin123
Sample tokens can be generated from Admin.
